# dsvideo

Dsvideo 是面向 Dsivio 内置插件开发的个人视频创作项目，包含视频编排语言、素材生成、编译与渲染、CLI 和 Studio 编辑预览。

当前版本：`0.1.0`。发行包：`@dsvideo/dsvideo`。本仓库为私有开发基线，不发布到 npm。

## 本地开发

需要 Node.js 22.15+ 和 pnpm 10.33.0。

```bash
npx --yes pnpm@10.33.0 install --frozen-lockfile
./dsvideo --version
./dsvideo --help
./dsvideo studio --help
```

```bash
pnpm check
pnpm test
pnpm docs:dev
```

Studio 的项目参数、Runtime 及构建选项通过 `./dsvideo studio --help` 和 `./dsvideo --help` 查看。
本地渲染还需要 ffmpeg、ffprobe 和 Chromium；Python/uv 用于选用的本地媒体服务。依赖安装不自动安装浏览器。

## 开发基线

- CLI：`bin/dsvideo.mjs`，启动脚本：`./dsvideo`。
- 包命名空间：`@dsvideo/*`，公开 API：`@dsvideo/dsvideo/*`。
- 项目配置：`dsvideo.runtime.json`，本地状态：`.dsvideo/`，环境变量前缀：`DSVIDEO_`。
- Agent 技能：`skills/dsvideo/`；Studio：`packages/studio/`。
- 示例：`examples/`；媒体服务：`services/`。

后续按具体任务逐步适配 Dsivio。目前完成项目身份及开发基线整理，尚未完成内置插件接入。
媒体生成已内置 `@dsvideo/provider-dsivio`，通过 `dsivio media` CLI 调用 App。六个直连云端 Provider 已删除，本地 Provider 保留。旧配置不会自动迁移。

修改功能和调用流程前，遵循相邻 Dsivio 项目的[统一工程规范](../Dsivio/docs/engineering-standards.md)及相关 ADR。
