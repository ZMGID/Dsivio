from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import tempfile
from typing import Mapping

from .resources import default_nltk_data_root


def _positive_integer(value: str, name: str, maximum: int | None = None) -> int:
    try:
        parsed = int(value)
    except ValueError as error:
        raise ValueError(f"{name} must be an integer") from error
    if parsed <= 0 or (maximum is not None and parsed > maximum):
        suffix = f" no greater than {maximum}" if maximum is not None else ""
        raise ValueError(f"{name} must be positive{suffix}")
    return parsed


@dataclass(frozen=True, slots=True)
class ServiceConfig:
    port: int
    model: str
    device: str
    compute: str
    batch_size: int
    input_roots: tuple[Path, ...]
    nltk_data_root: Path
    max_request_bytes: int
    max_audio_bytes: int
    model_cache: Path | None
    alignment_languages: tuple[str, ...]

    @classmethod
    def from_environment(cls, environment: Mapping[str, str] | None = None) -> "ServiceConfig":
        env = os.environ if environment is None else environment
        device = env.get("DSVIDEO_WHISPERX_DEVICE", "cpu").strip()
        model = env.get("DSVIDEO_WHISPERX_MODEL", "small").strip()
        compute = env.get(
            "DSVIDEO_WHISPERX_COMPUTE",
            "int8" if device == "cpu" else "float16",
        ).strip()
        if not model:
            raise ValueError("DSVIDEO_WHISPERX_MODEL must not be empty")
        if not device:
            raise ValueError("DSVIDEO_WHISPERX_DEVICE must not be empty")
        if not compute:
            raise ValueError("DSVIDEO_WHISPERX_COMPUTE must not be empty")

        raw_roots = env.get("DSVIDEO_WHISPERX_INPUT_ROOTS", tempfile.gettempdir())
        roots = tuple(
            Path(item).expanduser().resolve()
            for item in raw_roots.split(os.pathsep)
            if item.strip()
        )
        if not roots:
            raise ValueError("DSVIDEO_WHISPERX_INPUT_ROOTS must contain at least one path")

        languages = tuple(dict.fromkeys(env.get("DSVIDEO_WHISPERX_ALIGNMENT_LANGUAGES", "").split()))
        if any(not language.isascii() or not language.isalpha() or language != language.lower() for language in languages):
            raise ValueError("DSVIDEO_WHISPERX_ALIGNMENT_LANGUAGES must contain lowercase language codes")
        return cls(
            model_cache=Path(env["DSVIDEO_WHISPERX_MODEL_CACHE"]).expanduser().resolve() if env.get("DSVIDEO_WHISPERX_MODEL_CACHE") else None,
            alignment_languages=languages,
            port=_positive_integer(env.get("DSVIDEO_WHISPERX_PORT", "8765"), "DSVIDEO_WHISPERX_PORT", 65535),
            model=model,
            device=device,
            compute=compute,
            batch_size=_positive_integer(
                env.get("DSVIDEO_WHISPERX_BATCH_SIZE", "8"),
                "DSVIDEO_WHISPERX_BATCH_SIZE",
            ),
            input_roots=roots,
            nltk_data_root=Path(
                env.get("DSVIDEO_WHISPERX_NLTK_DATA", str(default_nltk_data_root()))
            ).expanduser().resolve(),
            max_request_bytes=_positive_integer(
                env.get("DSVIDEO_WHISPERX_MAX_REQUEST_BYTES", str(64 * 1024)),
                "DSVIDEO_WHISPERX_MAX_REQUEST_BYTES",
            ),
            max_audio_bytes=_positive_integer(
                env.get("DSVIDEO_WHISPERX_MAX_AUDIO_BYTES", str(512 * 1024 * 1024)),
                "DSVIDEO_WHISPERX_MAX_AUDIO_BYTES",
            ),
        )
