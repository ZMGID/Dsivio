import { createAuthorFrontendHostFacet } from "@dsvideo/elaborator";

import { svsFrontend, svsManifest } from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{ manifest: svsManifest }],
  hostFacets: [createAuthorFrontendHostFacet(svsFrontend)],
};

export default dsvideoPackage;
