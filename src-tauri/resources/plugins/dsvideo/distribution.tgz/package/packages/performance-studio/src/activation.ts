import { createStudioCompanionHostFacet } from "@dsvideo/studio-adapter";
import { performanceStudioTrackCompanions, performanceStudioParameterCompanions } from "./index.js";
export default {
  format: "dsvideo.node-package@1" as const,
  hostFacets: [createStudioCompanionHostFacet({ tracks: performanceStudioTrackCompanions, parameters: performanceStudioParameterCompanions })],
};
