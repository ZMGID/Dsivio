import { speechAlignmentComponent, speechAlignmentManifest } from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{ manifest: speechAlignmentManifest }],
  components: [speechAlignmentComponent],
};
export default dsvideoPackage;
