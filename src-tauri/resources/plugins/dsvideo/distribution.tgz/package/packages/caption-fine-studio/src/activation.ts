import { createStudioCompanionHostFacet } from "@dsvideo/studio-adapter";
import { captionFineStudioTrackCompanions, captionFineStudioParameterCompanions } from "./index.js";

export default {
  format: "dsvideo.node-package@1" as const,
  hostFacets: [createStudioCompanionHostFacet({ tracks: captionFineStudioTrackCompanions, parameters: captionFineStudioParameterCompanions })],
};
