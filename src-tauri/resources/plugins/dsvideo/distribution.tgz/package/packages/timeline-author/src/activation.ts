import { decodeClockSurface } from "@dsvideo/program-space";
import { createMarkupSurfaceHostFacet } from "@dsvideo/markup";
import {
  decodeTimelineAuthorSurface, timelineAuthorComponent, timelineAuthorManifest,
  timelineAuthorModuleRef,
  timelineAuthorMarkupSurfaces,
} from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{
    manifest: timelineAuthorManifest,
  }],
  components: [timelineAuthorComponent],
  hostFacets: [createMarkupSurfaceHostFacet({
    module: timelineAuthorModuleRef,
    declaration: timelineAuthorMarkupSurfaces.find((item) => item.name === "timeline")!, handler: decodeTimelineAuthorSurface,
  }), createMarkupSurfaceHostFacet({ module: timelineAuthorModuleRef,
    declaration: timelineAuthorMarkupSurfaces.find(item => item.name === "clock")!, handler: decodeClockSurface,
  })],
};
export default dsvideoPackage;
