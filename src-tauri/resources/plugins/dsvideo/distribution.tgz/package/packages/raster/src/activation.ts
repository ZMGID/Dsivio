import { rasterManifest } from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{ manifest: rasterManifest }],
};
export default dsvideoPackage;
