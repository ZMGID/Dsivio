import { createAuthorFrontendHostFacet } from "@dsvideo/elaborator";
import { createMarkupSurfaceHostFacet } from "@dsvideo/markup";

import {
  decodeTextRenderSurface,
  decodeTextValueSurface,
  textComponent,
  textManifest,
  textModuleRef,
  textSvsFrontend,
  textMarkupSurfaces,
} from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{ manifest: textManifest }],
  components: [textComponent],
  hostFacets: [
    createAuthorFrontendHostFacet(textSvsFrontend),
    createMarkupSurfaceHostFacet({
      module: textModuleRef,
    declaration: textMarkupSurfaces.find((item) => item.name === "value")!,
      handler: decodeTextValueSurface,
    }),
    createMarkupSurfaceHostFacet({
      module: textModuleRef,
    declaration: textMarkupSurfaces.find((item) => item.name === "render")!,
      handler: decodeTextRenderSurface,
    }),
  ],
};

export default dsvideoPackage;
