import { narrativeComponent, narrativeManifest } from "./index.js";
export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{ manifest: narrativeManifest }],
  components: [narrativeComponent],
};
export default dsvideoPackage;
