import { createStudioTrackCompanionHostFacet } from "@dsvideo/studio-adapter";
import { screenOverlayStudioTrackCompanions } from "./index.js";

export default {
  format: "dsvideo.node-package@1" as const,
  hostFacets: [createStudioTrackCompanionHostFacet(screenOverlayStudioTrackCompanions)],
};
