# `@dsvideo/screen-overlay-studio`

Dsvideo Studio Companion for `@dsvideo/screen-overlay`.
