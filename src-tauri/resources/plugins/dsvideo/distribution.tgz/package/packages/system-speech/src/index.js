import { sealGenerationPortTable, sealGenerationPortRequest } from "@dsvideo/generation";
import { defineExactModelModule } from "@dsvideo/model-kit";
export const systemSpeechModuleRef = { name:"@dsvideo/system-speech",version:"1" };
export const systemSpeechPorts = sealGenerationPortTable({model:"system-tts",result:"audio",ports:[
  {name:"text",value:{kind:"text",maxChars:10000},minItems:1,maxItems:1},
  {name:"voice",value:{kind:"text"},minItems:0,maxItems:1},
],requires:[]});
export const systemSpeechDefinition = defineExactModelModule({module:systemSpeechModuleRef,endpoints:[{key:"speech",requestTypeName:"SystemSpeechRequest",producerName:"request-system-tts",ports:systemSpeechPorts}]});
export const sealSystemSpeechRequest = ports => sealGenerationPortRequest(systemSpeechPorts,ports);
