import { systemSpeechDefinition as definition } from "./index.js";
export default {format:"dsvideo.node-package@1",modules:[{manifest:definition.manifest}],components:[definition.component],hostFacets:[definition.hostFacet]};
