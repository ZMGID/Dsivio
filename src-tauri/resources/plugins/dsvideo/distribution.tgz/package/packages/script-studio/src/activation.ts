import { createStudioCompanionHostFacet } from "@dsvideo/studio-adapter";

import { scriptStudioCompanions } from "./index.js";

export default {
  format: "dsvideo.node-package@1" as const,
  hostFacets: [createStudioCompanionHostFacet({ scripts: scriptStudioCompanions })],
};
