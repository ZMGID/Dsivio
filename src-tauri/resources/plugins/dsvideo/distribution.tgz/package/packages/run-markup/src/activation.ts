import { createRunFrontendHostFacet } from "@dsvideo/run";

import { runMarkupFrontend } from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  hostFacets: [createRunFrontendHostFacet(runMarkupFrontend)],
};

export default dsvideoPackage;
