import { timelineComponent, timelineManifest } from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{ manifest: timelineManifest }],
  components: [timelineComponent],
};
export default dsvideoPackage;
