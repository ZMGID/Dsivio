import { compositionComponent, compositionManifest } from "./index.js";
export const dsvideoPackage = { format: "dsvideo.node-package@1" as const, modules: [{ manifest: compositionManifest }], components: [compositionComponent] };
export default dsvideoPackage;
