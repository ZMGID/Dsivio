# `@dsvideo/host`

The minimal opaque `HostFacet` envelope: an ABI, logical offers, locked identity and inert
implementation. Package loading can carry it without learning what it does; only the exact Host ABI
may interpret it. Source and asset sessions live separately in `@dsvideo/workspace`.
