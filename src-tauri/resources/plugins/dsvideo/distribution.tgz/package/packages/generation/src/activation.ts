import { generationComponent, generationManifest } from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{ manifest: generationManifest }],
  components: [generationComponent],
};

export default dsvideoPackage;
