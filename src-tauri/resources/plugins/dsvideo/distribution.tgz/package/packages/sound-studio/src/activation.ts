import { createStudioCompanionHostFacet } from "@dsvideo/studio-adapter";
import { soundStudioTrackCompanions, soundStudioParameterCompanions } from "./index.js";
export default {
  format: "dsvideo.node-package@1" as const,
  hostFacets: [createStudioCompanionHostFacet({ tracks: soundStudioTrackCompanions, parameters: soundStudioParameterCompanions })],
};
