import { createMarkupSurfaceHostFacet } from "@dsvideo/markup";

import {
  decodeMediaAudioSurface, decodeMediaFontSurface, decodeMediaImageSurface, decodeMediaVideoSurface, mediaComponent,
  mediaManifest,
  mediaModuleRef,
  mediaMarkupSurfaces,
} from "./index.js";

export const dsvideoPackage = {
  format: "dsvideo.node-package@1" as const,
  modules: [{ manifest: mediaManifest }],
  components: [mediaComponent],
  hostFacets: [
    createMarkupSurfaceHostFacet({
      module: mediaModuleRef,
    declaration: mediaMarkupSurfaces.find((item) => item.name === "image")!,
      handler: decodeMediaImageSurface,
    }),
    createMarkupSurfaceHostFacet({
      module: mediaModuleRef,
    declaration: mediaMarkupSurfaces.find((item) => item.name === "audio")!,
      handler: decodeMediaAudioSurface,
    }),
    createMarkupSurfaceHostFacet({
      module: mediaModuleRef,
    declaration: mediaMarkupSurfaces.find((item) => item.name === "video")!,
      handler: decodeMediaVideoSurface,
    }),
    createMarkupSurfaceHostFacet({
      module: mediaModuleRef,
    declaration: mediaMarkupSurfaces.find((item) => item.name === "font")!,
      handler: decodeMediaFontSurface,
    }),
  ],
};

export default dsvideoPackage;
