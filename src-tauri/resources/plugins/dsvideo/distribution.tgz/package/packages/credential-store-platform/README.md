# `@dsvideo/credential-store-platform`

An explicitly selected CredentialStore policy: macOS Keychain on macOS, Windows Credential Locker
on Windows, and an unencrypted, owner-private file on Linux. Other platforms are unsupported by this
package and report an error. Linux may offer other credential services; this package chooses file
storage there and does not detect or integrate those services.

A Profile can select this package to use that policy on Linux, macOS and Windows.
`@dsvideo/credential-store-os`, `@dsvideo/credential-store-file` and `@dsvideo/credential-store-env`
remain selectable directly for a deployment with a different storage choice.

## Select it

```json
{
  "credentials": { "platform": { "use": "@dsvideo/credential-store-platform" } },
  "endpoints": { "example.media": {
    "use": "@example/provider-media",
    "config": { "apiKey": { "store": "platform", "key": "example.key" } }
  } }
}
```

The Endpoint still owns its acquisition flow and the Store only persists the result:

```bash
dsvideo auth login example.media --runtime <profile>
dsvideo auth status example.media --runtime <profile>
dsvideo auth logout example.media --runtime <profile>
```

## What it does not do

The choice is made once per host, from the platform the Runtime is running on. This is not a lookup
chain: a miss or failure in one store never tries another, and no credential is migrated between them. A
credential stored in a locker stays in that locker; a credential stored in a file stays in that file.

## Configuration

- `path` selects the directory for Linux file storage, resolved against the Host state root printed by
  `dsvideo paths`. The default is the same `credentials` directory `@dsvideo/credential-store-file` uses,
  so on Linux, switching between the two Stores finds the credential already stored.
- WSL uses the Linux file Store. If the Host state root is on a Windows-mounted drive, select a
  private directory in the WSL Linux filesystem with `path`; the Store keeps its permission check.
- `service` selects the locker service name. The OS Store's own default applies when it is absent.

## Storage on each platform

On macOS and Windows the credential is held by the platform locker, with exactly the rules of
`@dsvideo/credential-store-os`: it is encrypted and access-controlled by the operating system, and it
follows that locker’s access and synchronization policy. Windows Credential Locker may roam
credentials through the user’s Microsoft account.

On Linux the credential is held by an owner-private document with exactly the rules of
`@dsvideo/credential-store-file`: unencrypted JSON, one document per key, directory mode `0700`, file
mode `0600`, outside the video project, and never enumerated or indexed. Filesystem path-length
limits apply to an overlong key, which fails rather than selecting another name. A damaged document
can be replaced by `auth login` or deleted by `auth logout` without decoding the old value.

The shipped Dsivio adapter declares no credentials and does not use this Store.
