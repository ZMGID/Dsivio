import { mkdtemp, writeFile, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { canonicalize, wakeAfter, EndpointServiceError } from "@dsvideo/endpoint-kit";
import { verifyWhisperXAlignmentRequest, assertWhisperXEvidenceWav, interpretWhisperXTranscript, whisperXCapabilities } from "@dsvideo/whisperx";
import { sealAlignedTranscriptEvidence, speechEvidenceTypes } from "@dsvideo/speech-evidence";

export function createDsivioAlignment({ offer, media, interval, operationTimeoutMs }) {
  const receipt = h => ({ source: "dsvideo", key: h.key, ...(h.id ? { id: h.id } : {}) });
  const pending = h => ({ ...wakeAfter(h, interval, Date.now(), { phase: "Dsivio WhisperX alignment" }), receipt: receipt(h) });
  const discard = async h => { if (h.directory) await rm(h.directory, { recursive: true, force: true }); };
  const observe = async (task,h) => {
    const next = { ...h, id:task.id };
    if (task.status === "running") return pending(next);
    if (task.status !== "succeeded") { await discard(h); return {status:"failed",receipt:receipt(next),failure:{code:"DSIVIO_ASR_FAILED",message:task.error || task.status}}; }
    return { status:"ready",handle:{...next,result:task.result,outputs:task.outputs},receipt:receipt(next) };
  };
  return {
    capability: whisperXCapabilities.alignment, returns: speechEvidenceTypes.alignedTranscript, lifecycle:"asynchronous",
    supports: need => { try { verifyWhisperXAlignmentRequest(need.constraints); return {status:"supported"}; } catch(e) { return {status:"unsupported",reason:String(e)}; } },
    endpoint: {
      async start(context) {
        const request = verifyWhisperXAlignmentRequest(context.need.constraints);
        const audio = await context.resources.get(request.audio.resource);
        if (!audio || audio.byteLength !== request.audio.size) throw new Error("Alignment evidence missing or changed");
        assertWhisperXEvidenceWav(audio,request.sampleFrames);
        const directory = await mkdtemp(join(tmpdir(),"dsvideo-dsivio-asr-"));
        const path = join(directory,"evidence.wav"); await writeFile(path,audio);
        const h = {contract:"dsvideo.dsivio-alignment@1", key:"alignment:"+createHash("sha256").update(String(context.operation ?? context.command.id)).digest("hex"),directory,sampleFrames:request.sampleFrames,language:request.language,startedAt:Date.now()};
        await context.checkpoint?.({handle:h,receipt:receipt(h)});
        const args=["media","transcribe",path,"--language",request.language,"--sample-frames",String(request.sampleFrames),"--timestamps","word","--model",offer.model.id,"--no-wait","--source","dsvideo","--idempotency-key",h.key];
        if (offer.model.description?.factsRevision) args.push("--description-revision",offer.model.description.factsRevision);
        let task;
        try { task=await media(args); } catch(e) {
          if(e.json?.id) task=e.json;
          else if ([2,3,6,7].includes(e.exitCode)) {await discard(h);throw e;}
          else return pending(h); // Only look up the original key after an uncertain response.
        }
        if (!task?.id) return pending(h);
        const next={...h,id:task.id};await context.checkpoint?.({handle:next,receipt:receipt(next)});
        return observe(task,next);
      },
      async poll(context) {
        const h=context.handle;
        if(h?.contract!=="dsvideo.dsivio-alignment@1") throw new Error("Invalid alignment handle");
        if(Date.now()-h.startedAt>operationTimeoutMs) return {status:"failed",receipt:receipt(h),failure:{code:"DSIVIO_ASR_TIMEOUT",message:"Query the existing Dsivio task before repeating alignment"}};
        let task;
        try {task=await media(h.id?["media","status",h.id]:["media","status","--source","dsvideo","--idempotency-key",h.key]);}
        catch(e) {if(e.json?.id) task=e.json;else if(e.exitCode===6 || /MEDIA_TASK_NOT_FOUND|TIMEOUT|not running/i.test(e.message)) return pending(h);else throw e;}
        return observe(task,h);
      },
      async collect(context) {
        const h=context.handle;
        let raw=h.result;
        if(!raw) {const path=h.outputs?.[0]?.path;if(!path) throw new Error("Dsivio transcript missing");raw=JSON.parse(await readFile(path,"utf8"));}
        if(raw.schema!=="dsivio.media.transcript/1" || raw.sampleFrames!==h.sampleFrames || raw.sampleRate!==16000 || raw.language!==h.language) throw new EndpointServiceError("DSIVIO_ASR_EVIDENCE_INVALID","Transcript does not match submitted audio sample count");
        const evidence=sealAlignedTranscriptEvidence({passages:interpretWhisperXTranscript(raw,h.sampleFrames)});
        await discard(h);
        return {status:"completed",receipt:receipt(h),result:{value:{kind:"inline",value:canonicalize(evidence)}}};
      },
      async cancel(context) {
        let h=context.handle;
        if(!h.id) {const task=await media(["media","status","--source","dsvideo","--idempotency-key",h.key]);h={...h,id:task.id};}
        const response=await media(["media","cancel",h.id]);
        if(response.outcome==="confirmed") await discard(h);
        return {status:({confirmed:"confirmed",requested:"accepted",unsupported:"unsupported","too-late":"too-late"})[response.outcome]??"unsupported"};
      },
    },
  };
}
