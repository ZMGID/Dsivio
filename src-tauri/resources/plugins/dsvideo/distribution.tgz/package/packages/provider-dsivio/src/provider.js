import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { homedir, tmpdir } from "node:os";
import { basename, delimiter, dirname, extname, join } from "node:path";

import { EndpointServiceError, canonicalize, defineEndpointPackage, wakeAfter } from "@dsvideo/endpoint-kit";
import { generationTypes, sealGeneratedImageSet, sealGeneratedVideoSet } from "@dsvideo/generation";

import { IMAGE_MODELS, PORT_TABLES, VIDEO_MODELS, fulfilments, portsFor, argumentName } from "./models.js";

export const providerModule = { name: "@dsvideo/provider-dsivio", version: "1" };

const EXTENSIONS = new Map([
  ["image/png", ".png"],
  ["image/jpeg", ".jpg"],
  ["image/webp", ".webp"],
  ["video/mp4", ".mp4"],
  ["video/webm", ".webm"],
  ["video/quicktime", ".mov"],
  ["audio/mpeg", ".mp3"],
  ["audio/mp3", ".mp3"],
  ["audio/wav", ".wav"],
  ["audio/x-wav", ".wav"],
]);
const MEDIA_TYPES = new Map([...EXTENSIONS].map(([mediaType, extension]) => [extension, mediaType]));

/** What differs between the two result kinds; everything else is shared. */
const KINDS = {
  image: { returns: generationTypes.imageSet, seal: sealGeneratedImageSet, resultKey: "images" },
  video: { returns: generationTypes.videoSet, seal: sealGeneratedVideoSet, resultKey: "videos" },
};

/** Refuse, before anything is submitted, what Dsivio's own rules for this model would refuse. */
export function checkLimits(offer, ports) {
  const descriptor = offer.model.description;
  if (descriptor?.descriptionVersion === 1) {
    for (const [port, values] of Object.entries(ports)) {
      if (!values?.length || port === "webSearch") continue;
      if (offer.kind === "video" && port === "aspectRatio" && values[0] === "auto") continue;
      const arg = descriptor.arguments?.[argumentName(offer.kind, port)];
      if (!arg) return { status: "unsupported", reason: `${offer.model.id} does not accept ${port}` };
      const facts = arg.facts ?? {};
      const refuse = (reason) => ({ status: "unsupported", reason: `${offer.model.id}: ${port} ${reason}` });
      if (arg.dataType === "mediaList") {
        if (facts.maxCount != null && values.length > facts.maxCount) return refuse(`allows at most ${facts.maxCount} items`);
        for (const item of values) {
          const blob = item?.artifact;
          if (facts.maxBytes != null && blob?.size > facts.maxBytes) return refuse(`exceeds ${facts.maxBytes} bytes`);
          if (blob?.mediaType && facts.mimePatterns?.length && !facts.mimePatterns.some(pattern => pattern === blob.mediaType || (pattern.endsWith("/*") && blob.mediaType.startsWith(pattern.slice(0, -1))))) return refuse(`does not accept ${blob.mediaType}`);
        }
      } else {
        const value = values[0];
        if (facts.allowed?.length && !facts.allowed.map(String).includes(String(value)) && !facts.specialValues?.map(String).includes(String(value))) return refuse(`does not accept ${value}`);
        if (typeof value === "number" && ((facts.minimum != null && value < facts.minimum) || (facts.maximum != null && value > facts.maximum))) return refuse("is outside the declared range");
        const length = typeof value === "string" ? (facts.lengthUnit === "unicodeCodePoint" ? [...value].length : value.length) : undefined;
        if (length != null && ((facts.minLength != null && length < facts.minLength) || (facts.maxLength != null && length > facts.maxLength))) return refuse("has an invalid length");
      }
    }
  }
  if (scalar(ports.webSearch) === true) return { status: "unsupported", reason: `${offer.model.id}: web search is not available through Dsivio; set web-search to false` };
  if (descriptor?.descriptionVersion === 1) return { status: "supported" }; // App owns cross-argument rules and final validation.
  const c = offer.model.capabilities;
  if (c === null || c === undefined) return { status: "supported" };
  const one = (name) => scalar(ports[name]);
  const count = (...names) => names.reduce((sum, name) => sum + (ports[name]?.length ?? 0), 0);
  const refuse = (reason) => ({ status: "unsupported", reason: `${offer.model.id}: ${reason}` });
  const inList = (value, list) => value === undefined || !Array.isArray(list) || list.length === 0 || list.map(String).includes(String(value));
  if (one("webSearch") === true) return refuse("web search is not available through Dsivio; set web-search to false");
  if (offer.kind === "video") {
    if (!inList(one("duration"), c.durations)) return refuse(`duration ${one("duration")}s is not offered (allowed: ${c.durations.join(", ")})`);
    if (!inList(one("resolution"), c.resolutions)) return refuse(`resolution ${one("resolution")} is not offered (allowed: ${c.resolutions.join(", ")})`);
    if (one("aspectRatio") !== "auto" && !inList(one("aspectRatio"), c.ratios)) return refuse(`aspect ratio ${one("aspectRatio")} is not offered (allowed: ${c.ratios.join(", ")})`);
    if (c.lastFrameNeedsFirst !== false && count("lastFrame") > 0 && count("firstFrame") === 0) return refuse("a last frame needs a first frame");
    const references = count("referenceImage", "referenceVideo", "referenceAudio", "images");
    if (c.framesExcludeReferences && references > 0 && count("firstFrame", "lastFrame") > 0) return refuse("first/last frames cannot be combined with reference media");
    if ((ports.referenceImage?.length ?? 0) > c.maxReferenceImages || (ports.images?.length ?? 0) > c.maxReferenceImages) return refuse(`at most ${c.maxReferenceImages} reference images`);
    if ((ports.referenceVideo?.length ?? 0) > c.maxReferenceVideos) return refuse(`at most ${c.maxReferenceVideos} reference videos`);
    if ((ports.referenceAudio?.length ?? 0) > c.maxReferenceAudios) return refuse(`at most ${c.maxReferenceAudios} reference audios`);
    if (c.referenceAudioNeedsVisual && count("referenceAudio") > 0 && count("referenceImage", "referenceVideo") === 0) return refuse("reference audio needs a reference image or video with it");
    if (c.maxPromptLength && String(one("prompt") ?? "").length > c.maxPromptLength) return refuse(`the prompt is longer than ${c.maxPromptLength} characters`);
  } else {
    if ((ports.images?.length ?? 0) > c.maxReferenceImages) return refuse(`at most ${c.maxReferenceImages} reference images`);
    if (one("resolution") !== "auto" && !inList(one("resolution"), c.sizes)) return refuse(`size ${one("resolution")} is not offered (allowed: ${c.sizes.join(", ")})`);
    if (one("aspectRatio") !== "auto" && !inList(one("aspectRatio"), c.ratios)) return refuse(`aspect ratio ${one("aspectRatio")} is not offered (allowed: ${c.ratios.join(", ")})`);
  }
  return { status: "supported" };
}

function scalar(values) {
  return values === undefined || values.length === 0 ? undefined : values[0];
}

function nonemptyText(value, subject) {
  if (typeof value !== "string" || value.trim().length === 0) throw new Error(`Dsivio ${subject} must be nonempty text`);
  return value;
}

function lastLine(text) {
  const lines = text.split("\n").map((line) => line.trim()).filter((line) => line.length > 0);
  return lines.length === 0 ? undefined : lines[lines.length - 1];
}

/** Dsivio accepts letters, digits, `-`, `_`, `.`, `:` only, in at most 128 characters. */
export function idempotencyKey(id) {
  // Hash the original identity: replacing punctuation alone can merge two operations.
  const raw = String(id);
  const label = raw.replace(/[^A-Za-z0-9._:-]/gu, "-").slice(0, 40);
  return `dsvideo-${label}-${createHash("sha256").update(raw).digest("hex")}`;
}

function describe(error) {
  return error instanceof Error ? error.message : String(error);
}

/** The Dsivio command line, with the launcher Dsivio installs at startup as a fallback. */
export function resolveCommand(declared) {
  const command = declared ?? "dsivio";
  if (command.includes("/") || command.includes("\\")) return command;
  for (const directory of (process.env.PATH ?? "").split(delimiter)) {
    if (directory.length === 0) continue;
    const names = process.platform === "win32" ? [command, `${command}.exe`, `${command}.cmd`] : [command];
    for (const name of names) {
      const candidate = join(directory, name);
      if (existsSync(candidate)) return candidate;
    }
  }
  const installed = join(homedir(), ".kivio", "bin", process.platform === "win32" ? "dsivio.cmd" : "dsivio");
  return existsSync(installed) ? installed : command;
}

function runCommand(file, args, input, timeoutMs) {
  return new Promise((resolve, reject) => {
    // Execute the installed launcher without sending user arguments through a shell.
    let executable = file;
    let argv = args;
    if (/\.cmd$/iu.test(file)) {
      // Dsivio's installed shim names the executable. Bypass cmd.exe so JSON, %, & and quotes
      // remain literal arguments. Only the exact launcher format is accepted.
      const shim = readFileSync(file, "utf8").trim().match(/^@"([^"\r\n]+)"(?: "([^"\r\n]+)")? %\*$/u);
      if (!shim) throw new EndpointServiceError("DSIVIO_UNAVAILABLE", "Use the Dsivio-installed launcher or configure command with the executable path");
      executable = shim[1];
      argv = shim[2] ? [shim[2], ...args] : args;
    }
    const child = spawn(executable, argv, { stdio: ["pipe", "pipe", "pipe"], windowsHide: true, shell: false });
    let stdout = "";
    let stderr = "";
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
      if (stdout.length > 8 * 1024 * 1024) {
        child.kill("SIGKILL");
        reject(new EndpointServiceError("DSIVIO_INVALID_RESPONSE", "Dsivio CLI response exceeds 8 MiB"));
        stdout = "";
      }
    });
    child.stderr.on("data", (chunk) => { stderr = (stderr + chunk).slice(-65536); });
    child.on("error", (error) => {
      clearTimeout(timer);
      reject(new EndpointServiceError("DSIVIO_UNAVAILABLE", `Cannot run ${file}: ${describe(error)}`));
    });
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new EndpointServiceError("DSIVIO_TIMEOUT", `${file} ${args.slice(0, 2).join(" ")} did not answer within ${timeoutMs} ms`));
    }, timeoutMs);
    timer.unref?.();
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? -1, stdout, stderr });
    });
    child.stdin.on("error", () => {}); // A CLI that rejects flags may close stdin before the prompt is sent.
    child.stdin.end(input ?? "");
  });
}

function parseJson(stdout) {
  const line = stdout.trim();
  if (line.length === 0) return undefined;
  try {
    const value = JSON.parse(line);
    return value !== null && typeof value === "object" ? value : undefined;
  } catch {
    return undefined;
  }
}

/** Exit codes are the contract of `dsivio media` (see references/dsivio.md). */
const FAILURE_CODES = new Map([
  [2, "DSIVIO_REQUEST_REFUSED"],
  [3, "DSIVIO_REQUEST_REFUSED"],
  [4, "DSIVIO_GENERATION_FAILED"],
  [5, "DSIVIO_SUBMISSION_UNCERTAIN"],
  [6, "DSIVIO_NOT_RUNNING"],
  [7, "DSIVIO_CANCELLED"],
]);

function commandFailure(outcome, args, json) {
  const detail = typeof json?.error === "string"
    ? json.error
    : typeof json?.error?.message === "string"
      ? json.error.message
      : typeof json?.message === "string" ? json.message : lastLine(outcome.stderr) ?? "no diagnostic";
  const subject = `Dsivio ${args.slice(0, 2).join(" ")} exited ${outcome.code}`;
  const error = new EndpointServiceError(
    (typeof json?.code === "string" ? json.code : FAILURE_CODES.get(outcome.code)) ?? "DSIVIO_FAILED",
    outcome.code === 6 ? `${subject}: Dsivio is not running; open Dsivio and try again` : `${subject}: ${detail}`,
  );
  error.exitCode = outcome.code;
  error.json = json;
  return error;
}

function outputsOf(task) {
  return (Array.isArray(task.outputs) ? task.outputs : []).filter(entry => typeof entry?.path === "string" && entry.path.length > 0)
    .map(entry => ({ path: entry.path, ...(typeof entry.mime === "string" ? { mediaType: entry.mime } : {}) }));
}

function taskFailure(task, id) {
  if (task.submissionState === "uncertain") return { code: "DSIVIO_SUBMISSION_UNCERTAIN", message: `Dsivio task ${id}: submission uncertain; query this existing task before generating again. ${task.error ?? ""}` };
  const detail = typeof task.error === "string"
    ? task.error
    : typeof task.error?.message === "string"
      ? task.error.message
      : "no diagnostic";
  // A failed task that can still be resumed kept a receipt the provider stopped returning: it may
  // have been charged, so it is reported apart from an ordinary generation failure.
  if (task.canResume === true) {
    return { code: "DSIVIO_RECEIPT_LOST", message: `Dsivio task ${id} (receipt ${task.remoteId ?? "unknown"}): ${detail}. Check with the provider before generating again; \`dsivio media status ${id} --resume\` queries the same receipt.` };
  }
  return { code: "DSIVIO_GENERATION_FAILED", message: `Dsivio task ${id} failed: ${detail}` };
}

async function discard(directory) {
  if (typeof directory !== "string" || dirname(directory) !== tmpdir() || !basename(directory).startsWith("dsvideo-dsivio-")) return;
  await rm(directory, { recursive: true, force: true }).catch(() => {});
}

/** Flags for one request, from the ports Dsvideo sent and the table of the row that serves it. */
export function argumentsFor(kind, row, request, tmpFiles) {
  const table = PORT_TABLES[kind];
  const args = [];
  const options = {};
  for (const [name, values] of Object.entries(request.ports ?? {})) {
    const port = table[name];
    if (port === undefined || name === "prompt" || values === undefined || values.length === 0) continue;
    if (port.kind === "off-only") continue;
    // `auto` video ratio means "the model's default"; the image command accepts `auto` itself.
    if (port.kind === "flag" && kind === "video" && name === "aspectRatio" && values[0] === "auto") continue;
    if (port.kind === "option") options[port.key] = values[0];
    else if (port.kind === "flag") args.push(port.flag, String(values[0]));
    else if (port.kind === "switch") {
      if (values[0] === true) args.push(port.flag);
      else if (values[0] === false) options.generateAudio = false;
    } else if (port.kind === "media") {
      for (const item of values) args.push(port.flag, tmpFiles.get(item));
    }
  }
  if (Object.keys(options).length) args.push("--options-json", JSON.stringify(options));
  return args;
}

/**
 * The Dsivio models this endpoint serves, read once from `dsivio media models` when Dsvideo activates
 * it. `supports` is synchronous in Dsvideo, so it answers from this snapshot; a model changed in Dsivio
 * later is picked up after `dsvideo runtime down` / `dsvideo runtime up`.
 */
export function offersFrom(listed, options = {}) {
  const offers = [];
  for (const kind of ["image", "video"]) {
    const pin = kind === "image" ? options.imageModel : options.videoModel;
    const candidates = pin?.trim() ? listed.filter((entry) => entry.kind === kind && entry.id === pin) : listed;
    const found = fulfilments(kind, candidates);
    if (pin?.trim() && found.length === 0) {
      const reason = candidates.length === 0
        ? `Pinned ${kind} model ${pin} is not enabled in Dsivio Settings > 媒体创作`
        : `Pinned ${kind} model ${pin} has no compatible Dsvideo model`;
      offers.push({ ...placeholderOffers(reason).find((offer) => offer.kind === kind), diagnosticCode: "DSIVIO_MODEL_PIN_INVALID" });
    }
    for (const { row, model } of found) {
      offers.push({ kind, row, model, ports: portsFor(kind, row, model) });
    }
  }
  return offers;
}

/**
 * Dsvideo refuses to load an endpoint that declares no capability, which would hide the real cause
 * (Dsivio not running yet, or no model enabled). When nothing can be offered, declare the first
 * candidate of each kind with no model behind it: every request for it is refused with the reason,
 * and `dsvideo doctor` says what to do. Once Dsivio answers, the next start declares the real ones.
 */
export function placeholderOffers(reason) {
  return ["image", "video"].map((kind) => {
    const row = (kind === "image" ? IMAGE_MODELS : VIDEO_MODELS)[0];
    return { kind, row, model: { id: "(no model)", kind, capabilities: null }, ports: [], unavailable: reason };
  });
}

export function offerKey(dsvideo) {
  return `${dsvideo.module}#${dsvideo.name}`;
}

/**
 * `options.run(args, stdin)` executes the Dsivio command and returns its parsed JSON (tests replace it);
 * `options.offers` is the snapshot from `offersFrom`. Nothing here talks to a service or holds a key.
 */
export function createDsivioProvider(options) {
  const file = resolveCommand(options.command);
  const interval = options.pollIntervalMs ?? 5_000;
  const timeoutMs = options.requestTimeoutMs ?? 120_000;
  const concurrency = options.concurrency ?? 6;
  const operationTimeoutMs = options.operationTimeoutMs ?? 1_800_000;
  const offers = options.offers ?? [];

  const media = options.run ?? (async (args, input) => {
    const outcome = await runCommand(file, args, input, timeoutMs);
    const json = parseJson(outcome.stdout);
    if (outcome.code !== 0) throw commandFailure(outcome, args, json);
    if (json === undefined) throw new EndpointServiceError("DSIVIO_INVALID_RESPONSE", `Dsivio ${args.slice(0, 2).join(" ")} printed no JSON result`);
    return json;
  });

  function unsupported(offer, request) {
    if (offer.unavailable !== undefined) return { status: "unsupported", reason: offer.unavailable };
    const ports = request.constraints?.ports ?? {};
    const foreign = Object.keys(ports).filter((name) => !offer.ports.includes(name));
    for (const slot of request.pendingInputs ?? []) {
      if (!offer.ports.includes(slot.input)) foreign.push(slot.input);
    }
    if (foreign.length > 0) {
      return {
        status: "unsupported",
        reason: `${offer.model.id} in Dsivio does not accept ${[...new Set(foreign)].join(", ")}; choose another model in Dsivio Settings > 媒体创作`,
      };
    }
    return checkLimits(offer, request.constraints?.ports ?? {});
  }

  function cap(offer) {
    const kind = KINDS[offer.kind];
    const receipt = handle => ({ ...(handle.id ? { id: handle.id } : {}), ...(handle.key ? { key: handle.key, source: "dsvideo" } : {}) });
    const pending = (handle, phase) => ({ ...wakeAfter(handle, interval, Date.now(), { phase }), receipt: receipt(handle) });
    const failure = (handle, code, message) => ({ status: "failed", receipt: receipt(handle), failure: { code, message } });
    function observe(task, handle) {
      const next = { ...handle, id: nonemptyText(task.id ?? handle.id, "task id") };
      if (task.status === "running") return pending(next, task.error || `Dsivio task ${next.id} is running`);
      if (task.status === "failed") return { status: "failed", receipt: receipt(next), failure: taskFailure(task, next.id) };
      if (task.status === "cancelled") return failure(next, "DSIVIO_CANCELLED", `Dsivio task ${next.id} was cancelled`);
      if (task.status !== "succeeded") return failure(next, "DSIVIO_INVALID_RESPONSE", `Dsivio task ${next.id} reports unknown state ${String(task.status)}; check the existing task before generating again`);
      const outputs = outputsOf(task);
      if (!outputs.length) return failure(next, "DSIVIO_RESULT_MISSING", `Dsivio task ${next.id} succeeded without an output file`);
      return { status: "ready", handle: { ...next, outputs }, receipt: receipt(next) };
    }
    const endpoint = {
      kind: offer.kind,
      async start(context) {
        const request = context.need.constraints ?? { ports: {} };
        const support = unsupported(offer, { constraints: request });
        if (support.status !== "supported") throw new EndpointServiceError("DSIVIO_REQUEST_REFUSED", support.reason);
        const prompt = nonemptyText(scalar(request.ports.prompt), "prompt");
        const directory = await mkdtemp(join(tmpdir(), "dsvideo-dsivio-"));
        let retainInputs = false;
        try {
          const files = new Map();
          let counter = 0;
          for (const [name, values] of Object.entries(request.ports)) {
            if (PORT_TABLES[offer.kind][name]?.kind !== "media") continue;
            for (const item of values ?? []) {
              const artifact = item?.artifact;
              if (artifact === undefined) throw new Error(`A ${name} input carries no artifact`);
              const extension = EXTENSIONS.get(artifact.mediaType);
              if (name === "referenceAudio" && extension !== ".mp3" && extension !== ".wav") throw new EndpointServiceError("DSIVIO_REQUEST_REFUSED", `Unsupported ${name} media type ${artifact.mediaType}; use WAV or MP3`);
              const bytes = await context.resources.get(artifact.resource);
              if (bytes === undefined) throw new Error(`The ${name} input is unavailable`);
              const facts = offer.model.description?.arguments?.[argumentName(offer.kind, name)]?.facts;
              if (facts?.maxBytes != null && bytes.length > facts.maxBytes) throw new EndpointServiceError("DSIVIO_REQUEST_REFUSED", `${name} exceeds ${facts.maxBytes} bytes`);
              const path = join(directory, `input-${++counter}${extension ?? ".bin"}`);
              await writeFile(path, bytes);
              files.set(item, path);
            }
          }
          const handle = { contract: "dsvideo.dsivio-task@1", kind: offer.kind, route: offer.row.dsvideo.name, model: offer.model.id,
            key: idempotencyKey(context.operation ?? context.command.id), startedAt: Date.now(), inputDirectory: directory };
          const args = ["media", offer.kind, "--no-wait", "--source", "dsvideo", "--idempotency-key", handle.key,
            "--prompt-file", "-", ...argumentsFor(offer.kind, offer.row, request, files), "--model", offer.model.id];
          const revision = offer.model.description?.factsRevision;
          if (typeof revision === "string") args.push("--description-revision", revision);
          // Persist identity BEFORE the paid boundary, so a lost response can only lead to queries.
          await context.checkpoint?.({ handle, receipt: receipt(handle) });
          await context.reportProgress?.({ phase: `Submitting ${offer.kind} request to Dsivio (${offer.model.id})` });
          let submitted;
          try {
            submitted = await media(args, prompt);
          } catch (error) {
            if (typeof error?.json?.id === "string") {
              const next = { ...handle, id: error.json.id };
              await context.checkpoint?.({ handle: next, receipt: receipt(next) });
              return error.json.status ? observe(error.json, next) : pending(next, "Submission response uncertain; query the existing task");
            }
            if (["DSIVIO_TIMEOUT", "DSIVIO_INVALID_RESPONSE", "DSIVIO_SUBMISSION_UNCERTAIN", "DSIVIO_FAILED"].includes(error?.code) || (typeof error?.exitCode === "number" && ![2, 3, 6, 7].includes(error.exitCode))) {
              retainInputs = true; // The App may still be reading the staged inputs.
              return pending(handle, "Submission response uncertain; looking up the original key without resubmitting");
            }
            throw error;
          }
          if (typeof submitted?.id !== "string" || !submitted.id) {
            retainInputs = true;
            return pending(handle, "Submission returned no task ID; looking up the original key without resubmitting");
          }
          const next = { ...handle, id: submitted.id };
          await context.checkpoint?.({ handle: next, receipt: receipt(next) });
          return observe(submitted, next);
        } finally {
          if (!retainInputs) await discard(directory);
        }
      },
      async poll(context) {
        const handle = context.handle ?? {};
        if (handle.contract && (handle.contract !== "dsvideo.dsivio-task@1" || handle.kind !== offer.kind || handle.route !== offer.row.dsvideo.name)) throw new EndpointServiceError("DSIVIO_HANDLE_INVALID", "Task handle does not belong to this Dsivio model");
        if (handle.startedAt && Date.now() - handle.startedAt >= operationTimeoutMs) return failure(handle, "DSIVIO_WAIT_TIMEOUT", `Stopped waiting for Dsivio task ${handle.id ?? handle.key}; query the existing task in Dsivio before generating again${!handle.id && handle.inputDirectory ? `; staged inputs remain at ${handle.inputDirectory} until the submission is resolved` : ""}`);
        const args = handle.id ? ["media", "status", nonemptyText(handle.id, "task id")] : ["media", "status", "--source", "dsvideo", "--idempotency-key", nonemptyText(handle.key, "task key")];
        let task;
        try {
          task = await media(args);
        } catch (error) {
          if (["failed", "cancelled"].includes(error?.json?.status)) {
            await discard(handle.inputDirectory);
            return observe(error.json, handle);
          }
          if (error?.exitCode === 6 || ["DSIVIO_TIMEOUT", "DSIVIO_INVALID_RESPONSE", "DSIVIO_UNAVAILABLE", "DSIVIO_NOT_RUNNING"].includes(error?.code) || (!handle.id && /MEDIA_TASK_NOT_FOUND/u.test(error?.message ?? ""))) {
            return pending(handle, error?.exitCode === 6 || error?.code === "DSIVIO_NOT_RUNNING" ? "Dsivio is not running; open Dsivio to query the existing task" : `Waiting to query the existing Dsivio task: ${describe(error)}`);
          }
          throw error;
        }
        if (typeof task?.id === "string") await discard(handle.inputDirectory);
        return observe(task, handle);
      },
      async cancel(context) {
        let id = context.handle?.id;
        if (!id && context.handle?.key) {
          let task;
          try {
            task = await media(["media", "status", "--source", "dsvideo", "--idempotency-key", context.handle.key]);
          } catch (error) {
            if (typeof error?.json?.id !== "string") throw error;
            task = error.json;
          }
          if (task.status === "cancelled") return { status: "confirmed" };
          if (["failed", "succeeded"].includes(task.status)) return { status: "too-late" };
          id = task.id;
        }
        if (!id) return { status: "unsupported" };
        const result = await media(["media", "cancel", nonemptyText(id, "task id")]);
        const status = { confirmed: "confirmed", requested: "accepted", unsupported: "unsupported", "too-late": "too-late" }[result.outcome];
        if (!status) throw new EndpointServiceError("DSIVIO_INVALID_RESPONSE", "Dsivio returned an unknown cancellation outcome");
        return { status };
      },
      async collect(context) {
        const handle = context.handle ?? {};
        // Read legacy persisted one-output handles as well as the versioned full result set.
        const outputs = handle.outputs ?? (handle.path ? [{ path: handle.path, ...(handle.mediaType ? { mediaType: handle.mediaType } : {}) }] : []);
        if (!outputs.length) throw new EndpointServiceError("DSIVIO_RESULT_MISSING", "Dsivio result contains no output files");
        await context.reportProgress?.({ phase: `Collecting generated ${offer.kind}` });
        const artifacts = [];
        for (const output of outputs) {
          const path = nonemptyText(output.path, "output path");
          const mediaType = output.mediaType ?? MEDIA_TYPES.get(extname(path).toLowerCase());
          if (!mediaType?.startsWith(`${offer.kind}/`)) throw new EndpointServiceError("DSIVIO_RESULT_INVALID", `Dsivio output ${path} has an incompatible media type ${mediaType}`);
          const bytes = await readFile(path);
          artifacts.push(await context.resources.put(new Uint8Array(bytes), mediaType));
        }
        return { status: "completed", receipt: receipt(handle), result: { value: {
          kind: "inline", value: canonicalize(kind.seal({ [kind.resultKey]: artifacts })),
        } } };
      },
    };
    return {
      capability: { module: { name: offer.row.dsvideo.module, version: "1" }, name: offer.row.dsvideo.name },
      returns: kind.returns,
      lifecycle: "asynchronous",
      supports: (request) => unsupported(offer, request),
      endpoint,
    };
  }

  return defineEndpointPackage({
    module: providerModule,
    facet: "media",
    instance: options.instance,
    pool: options.pool,
    defaultConcurrency: concurrency,
    actionLimits: { submit: { concurrency }, poll: { concurrency: 4 }, collect: { concurrency: 1 } },
    // Dsivio bills the model account the user enabled in Dsivio; this Endpoint holds no account.
    capabilities: offers.map(cap),
  });
}

/** `dsivio media models`, or an empty list when Dsivio cannot answer (not running, no models): the
 *  endpoint then offers nothing and `dsvideo doctor` says why, instead of failing to load. */
export async function listModels(options, run) {
  const file = resolveCommand(options.command);
  try {
    if (run !== undefined) return await run(["media", "models"]);
    const outcome = await runCommand(file, ["media", "models"], undefined, 60_000);
    const json = parseJson(outcome.stdout);
    if (outcome.code !== 0) throw commandFailure(outcome, ["media", "models"], json);
    return Array.isArray(json) ? json : [];
  } catch {
    return [];
  }
}

/** What `dsvideo doctor` shows: whether Dsivio answers, which Dsvideo models it can serve, and what is left out. */
export async function probeDsivio(options, offers) {
  const file = resolveCommand(options.command);
  let listed;
  try {
    const outcome = await runCommand(file, ["media", "models"], undefined, 60_000);
    const json = parseJson(outcome.stdout);
    if (outcome.code !== 0) throw commandFailure(outcome, ["media", "models"], json);
    listed = Array.isArray(json) ? json : [];
  } catch (error) {
    return [{ severity: "error", code: "DSIVIO_UNAVAILABLE", message: describe(error) }];
  }
  const kinds = new Set(listed.map((entry) => entry?.kind));
  const missing = ["image", "video"].filter((kind) => !kinds.has(kind));
  const currentOffers = offers ?? offersFrom(listed, options);
  const pinDiagnostics = currentOffers.filter((offer) => offer.diagnosticCode !== undefined)
    .map((offer) => ({ severity: "error", code: offer.diagnosticCode, message: offer.unavailable }));
  if (missing.length > 0) {
    return [{
      severity: "error",
      code: "DSIVIO_NO_MODEL",
      message: `Dsivio has no ${missing.join(" and ")} model enabled; enable one in Dsivio Settings > 媒体创作`,
    }, ...pinDiagnostics];
  }
  const served = currentOffers.filter((offer) => offer.unavailable === undefined);
  const servedIds = new Set(served.map((offer) => offer.model.id));
  const diagnostics = [{
    severity: served.length ? "info" : "error",
    code: served.length ? "DSIVIO_MEDIA_READY" : "DSIVIO_NO_COMPATIBLE_MODEL",
    message: `Dsivio media ready at ${file}: ${served.map((offer) => `${offer.row.dsvideo.name} <- ${offer.model.id}`).join("; ") || "no Dsvideo model matches"}`,
  }];
  diagnostics.push(...pinDiagnostics);
  for (const entry of listed) {
    // A pin (or lower priority) can exclude a compatible model without making it unsupported.
    if (!servedIds.has(entry.id) && fulfilments(entry.kind, [entry]).length === 0) {
      diagnostics.push({
        severity: "warning",
        code: "DSIVIO_MODEL_NOT_IN_DSVIDEO",
        message: `${entry.id} is enabled in Dsivio but Dsvideo has no model it can stand in for, so Dsvideo cannot use it`,
      });
    }
  }
  for (const offer of served) {
    if (!offer.model.description && (offer.model.capabilities === null || offer.model.capabilities === undefined)) {
      diagnostics.push({
        severity: "warning",
        code: "DSIVIO_MODEL_UNKNOWN",
        message: `Dsivio has no facts about ${offer.model.id}; Dsvideo sends only the prompt to it`,
      });
    }
  }
  return diagnostics;
}
