# `@dsvideo/provider-dsivio`

Dsvideo 的媒体生成入口，通过正在运行的 Dsivio App 的 `dsivio media` CLI 提交、查询和收集任务。
不持有供应商地址或密钥，不读取 App 设置文件，不直连模型服务。

```json
{
  "format": "dsvideo.runtime-local@1",
  "dataRoot": ".dsvideo/runtimes/local",
  "credentials": {},
  "endpoints": {
    "dsivio.media": { "use": "@dsvideo/provider-dsivio" },
    "media.local": { "use": "@dsvideo/provider-media-local" },
    "hyperframes.local": { "use": "@dsvideo/provider-hyperframes-local" }
  }
}
```

模型来自「Dsivio 设置 > 媒体创作」的已启用模型池；同类匹配模型按 App 顺序选择。
当前沿用既有映射：GPT Image 2，Seedance 2/2 Fast/2.5，MiniMax H3，Grok Imagine Video/1.5。
其他模型、语音生成、云 ASR 和抠像暂不声明支持；本地 Provider 保留。
参数、参考素材上限来自 `dsivio media models` 的能力描述；已知不兼容输入在计划阶段拒绝，最终校验由 App 完成；提交携带 `factsRevision`，描述改变时付费前拒绝。

Endpoint `config` 仅接受 `command`、`imageModel`、`videoModel`、`pollIntervalMs`、`requestTimeoutMs`、`operationTimeoutMs`、`concurrency`。
`command` 可指定 Dsivio CLI 路径；默认找 PATH，再找 `~/.kivio/bin/dsivio`。
`imageModel` / `videoModel` 可指定 `dsivio media models` 列出的模型 ID；无效指定会报错，不改用其他模型。
修改模型池后，在当前工作结束时重新启动 Runtime，以加载新的模型快照。

```bash
dsivio media models
dsvideo doctor --endpoint dsivio.media
```

一次操作使用稳定幂等键，提交结果不确定不会重交；保留任务回执。
App 关闭时，已受理任务保持等待，重新打开 App 后查询原任务；不会切换供应商。
Adapter 只复制输入临时文件和产物到 Dsvideo 资源库，不删除 App 的任务与产物。
生成费用由 Dsivio 中所配置的模型账户决定；本适配器不宣称免费。

任务 handle 在提交前保存稳定 key；提交响应丢失时使用 `media status --source dsvideo --idempotency-key <key>`
只读找回原任务，不再次生成。该路径需要包含 key 查询能力的 Dsivio CLI。
轮询遇到 App 关闭或传输超时继续等待，默认最长 30 分钟（`operationTimeoutMs` 可调整）；到期保留回执并提示查询。
结果全部按 App 顺序收集；缺少输出、失败和取消为明确终态。取消转交 App，只有 confirmed 才确认，requested 仍为请求中，不承诺远程取消或退款。
GPT Image 的 `background` 仅在模型描述声明支持时提供。视频/音频参考若只支持 URL，不提供本地 blob 输入。

提交是否受理尚不明确时，输入副本暂时保留，找回 App 任务 ID 后清理；等待到期仍未找回时在诊断中给出保留目录，不能凭超时认定没有提交。

## App-owned local audio

The endpoint also fulfils `@dsvideo/whisperx#whisperx-alignment` using `dsivio media transcribe --model local/whisperx-small`. Evidence remains 16 kHz mono s16 WAV, and App word timestamps are converted to Dsvideo sample boundaries. Installation and the service belong to Dsivio. Unknown submit responses are reconciled by the original key.

`@dsvideo/system-speech#system-tts` uses the App's `local/system-tts`, backed by installed macOS/Windows system voices. Text and optional voice name are inputs; the result is an audio set containing WAV. Discover real voice names from `dsivio media models --kind speech`; do not assume the same voices exist on every machine.
