import { createStudioCompanionHostFacet } from "@dsvideo/studio-adapter";

import { filmStudioCompanions } from "./index.js";

export default {
  format: "dsvideo.node-package@1" as const,
  hostFacets: [createStudioCompanionHostFacet({ films: filmStudioCompanions })],
};
