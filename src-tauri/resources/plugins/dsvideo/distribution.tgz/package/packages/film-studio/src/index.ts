import { programSpaceTypes } from "@dsvideo/program-space";
import type { StudioFilmCompanion } from "@dsvideo/studio-adapter";
import { compositionTypes } from "@dsvideo/composition";
import { filmModuleRef } from "@dsvideo/film";
import { timelineTypes } from "@dsvideo/timeline";

/** Film owns the author vocabulary that selects its time source and peer Tracks. */
export const filmStudioCompanions: readonly StudioFilmCompanion[] = [{
  id: "film",
  match: { module: filmModuleRef, surface: "film", outputType: compositionTypes.composition },
  timeSources: [{ attribute: "timeline", type: timelineTypes.track }],
  tracks: {
    childSurface: "Track",
    sourceAttribute: "source",
    types: [compositionTypes.visualTrack, compositionTypes.audioTrack],
  },
}];
