import { createStudioTrackCompanionHostFacet } from "@dsvideo/studio-adapter";
import { mediaTrackStudioTrackCompanions } from "./index.js";

export default {
  format: "dsvideo.node-package@1" as const,
  hostFacets: [createStudioTrackCompanionHostFacet(mediaTrackStudioTrackCompanions)],
};
