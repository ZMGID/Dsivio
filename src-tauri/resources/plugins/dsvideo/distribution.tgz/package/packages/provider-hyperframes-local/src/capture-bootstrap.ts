/**
 * Preloaded into capture and browser-install processes, which never enter `bin/dsvideo.mjs`.
 *
 * `module.registerHooks` is process-local, so the resolver the launcher installs does not
 * reach a child that Node starts directly. This registers the same resolution environment
 * in the child, so its view of `@dsvideo/*` and of the machine packages those modules declare
 * is identical to its parent's.
 *
 * Only relative paths can be used here: no hook exists yet, and a Distribution ships its
 * package sources without any `node_modules` link between them.
 */
import { resolve } from "node:path";

// This preload belongs to the Provider the parent actually loaded. Inherited shell
// hints must not redirect its dependencies to a different Dsvideo installation.
const distributionRoot = resolve(import.meta.dirname, "../../..");

const { installDistributionPackageResolution, installExternalPackageResolution } =
  await import("../../package-loader-node/src/distribution-resolution.js");
installDistributionPackageResolution([distributionRoot]);

const { dsvideoHostPackageRoot } = await import("../../runtime-host-node/src/index.js");
installExternalPackageResolution([dsvideoHostPackageRoot()]);
