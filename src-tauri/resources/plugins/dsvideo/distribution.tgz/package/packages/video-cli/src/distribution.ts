import type { CliDistribution } from "@dsvideo/cli";
import {
  doctorProjectBuildResultRepository,
  openLocalRuntimeHost,
  openProjectBuildResultRepository,
} from "@dsvideo/runtime-local";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import {
  createVideoCompiler,
} from "./compiler.js";

// The Distribution root is the replaceable Dsvideo tool checkout, not this
// package's source directory and never the author's project.
const packageRoot = resolve(import.meta.dirname, "../../..");
const defaultBuildResultRepository = {
  use: "@dsvideo/build-result-fs",
  config: { path: ".dsvideo/results" },
} as const;

/** Official video authoring assembly for the generic CLI engine. */
export const videoCliDistribution: CliDistribution = {
  packageRoot,
  bootstrapPackages: [],
  initialRuntimeProfile: {
    format: "dsvideo.runtime-local@1",
    dataRoot: ".dsvideo/runtimes/local",
    credentials: {},
    endpoints: {
      "dsivio.media": {
        use: "@dsvideo/provider-dsivio",
      },
      "media.local": {
        use: "@dsvideo/provider-media-local",
      },
      "hyperframes.local": {
        use: "@dsvideo/provider-hyperframes-local",
      },
    },
  },
  createCompiler: createVideoCompiler,
  discoverSourcePackages: async (path, options) => {
    const { discoverVideoSourcePackages } = await import("./package-selection.js");
    return await discoverVideoSourcePackages(path, options);
  },
  openRuntimeHost: async (path, options) => await openLocalRuntimeHost(path, {
    packageRoot: options.packageRoot,
    ...(options.distributionPackageRoot === undefined
      ? {}
      : { distributionPackageRoot: options.distributionPackageRoot }),
    workerLaunch: {
      command: process.execPath,
      // The loaded Distribution owns its Worker entry and TypeScript/package resolution.
      args: [fileURLToPath(new URL("../../../bin/dsvideo.mjs", import.meta.url))],
    },
  }),
  openProjectResults: async (projectRoot, options) => {
    const opened = await openProjectBuildResultRepository(projectRoot, {
      ...options,
      distributionPackageRoot: options.distributionPackageRoot ?? packageRoot,
      defaultSelection: defaultBuildResultRepository,
    });
    return {
      location: opened.location,
      repository: opened.repository,
      close: async () => await opened.close?.(),
    };
  },
  diagnoseProjectResults: async (projectRoot, options) =>
    await doctorProjectBuildResultRepository(projectRoot, {
      ...options,
      distributionPackageRoot: options.distributionPackageRoot ?? packageRoot,
      defaultSelection: defaultBuildResultRepository,
    }),
};
