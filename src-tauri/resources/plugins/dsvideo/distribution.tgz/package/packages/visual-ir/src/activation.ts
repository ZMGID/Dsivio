import { visualIrManifest } from "./index.js";
export const dsvideoPackage = { format: "dsvideo.node-package@1" as const, modules: [{ manifest: visualIrManifest }] };
export default dsvideoPackage;
